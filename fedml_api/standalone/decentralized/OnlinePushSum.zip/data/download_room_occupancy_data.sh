#!/usr/bin/env bash
wget https://archive.ics.uci.edu/ml/machine-learning-databases/00357/occupancy_data.zip
unzip occupancy_data.zip

# data format: "date","Temperature","Humidity","Light","CO2","HumidityRatio","Occupancy"
# Data downloading:
```
http://archive.ics.uci.edu/ml/machine-learning-databases/00279/SUSY.csv.gz
https://archive.ics.uci.edu/ml/machine-learning-databases/00357/occupancy_data.zip
http://mlkd.csd.auth.gr/concept_drift.html
```
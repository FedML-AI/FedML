#!/usr/bin/env bash
wget http://archive.ics.uci.edu/ml/machine-learning-databases/00279/SUSY.csv.gz
gunzip SUSY.csv.gz